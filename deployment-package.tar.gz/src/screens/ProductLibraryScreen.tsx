import { View, Text, Pressable, ScrollView, TextInput, Modal, Keyboard, TouchableWithoutFeedback, Alert, KeyboardAvoidingView, Platform } from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/types";
import { useProductLibraryStore } from "../state/productLibraryStore";
import { useState, useEffect } from "react";
import { ProductType, ToleranceSpec } from "../types/product-library";
import CrossSection8048 from "../components/CrossSection8048";
import CrossSection1048 from "../components/CrossSection1048";
import CrossSection1248 from "../components/CrossSection1248";
import CrossSection1250 from "../components/CrossSection1250";
import CrossSection1648 from "../components/CrossSection1648";
import CrossSection1650 from "../components/CrossSection1650";

type Props = NativeStackScreenProps<RootStackParamList, "ProductLibrary">;

export default function ProductLibraryScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const products = useProductLibraryStore((s) => s.products);
  const addProduct = useProductLibraryStore((s) => s.addProduct);
  const updateProduct = useProductLibraryStore((s) => s.updateProduct);
  const deleteProduct = useProductLibraryStore((s) => s.deleteProduct);
  const addSubProduct = useProductLibraryStore((s) => s.addSubProduct);
  const updateSubProduct = useProductLibraryStore((s) => s.updateSubProduct);
  const deleteSubProduct = useProductLibraryStore((s) => s.deleteSubProduct);
  const initializeDefaultProducts = useProductLibraryStore((s) => s.initializeDefaultProducts);
  const migrateCrossSections = useProductLibraryStore((s) => s.migrateCrossSections);
  const migrateTolerances = useProductLibraryStore((s) => s.migrateTolerances);

  // Initialize default products on mount and run migrations
  useEffect(() => {
    if (products.length === 0) {
      initializeDefaultProducts();
    } else {
      // Migrate existing products to add cross-section components and update tolerance format
      migrateCrossSections();
      migrateTolerances();
    }
  }, []);

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);
  const [expandedSubProductId, setExpandedSubProductId] = useState<string | null>(null);

  // Sub-product modal state
  const [showSubProductModal, setShowSubProductModal] = useState(false);
  const [editingSubProductId, setEditingSubProductId] = useState<string | null>(null);
  const [currentProductId, setCurrentProductId] = useState<string | null>(null);
  const [subProductName, setSubProductName] = useState("");
  const [subProductDescription, setSubProductDescription] = useState("");
  const [subProductTolerances, setSubProductTolerances] = useState<ToleranceSpec[]>([]);

  // Cross-section properties
  const [subProductArea, setSubProductArea] = useState("");
  const [subProductEffectiveWebWidth, setSubProductEffectiveWebWidth] = useState("");
  const [subProductMomentOfInertia, setSubProductMomentOfInertia] = useState("");
  const [subProductDistanceToBottomFiber, setSubProductDistanceToBottomFiber] = useState("");

  // Strength characteristics
  const [subProductDeadLoad, setSubProductDeadLoad] = useState("");
  const [subProductDeadLoadPerLinearFoot, setSubProductDeadLoadPerLinearFoot] = useState<number | null>(null);
  const [subProductFc28Day, setSubProductFc28Day] = useState("");
  const [subProductFciRelease, setSubProductFciRelease] = useState("");
  const [subProductFpu, setSubProductFpu] = useState("");
  const [subProductCrossSectionComponent, setSubProductCrossSectionComponent] = useState("");

  // Auto-calculate dead load per linear foot when dead load (PSF) changes
  useEffect(() => {
    const psfValue = parseFloat(subProductDeadLoad);
    if (!isNaN(psfValue) && psfValue > 0) {
      // Dead load per linear foot = (PSF × 4 feet width)
      // Using 4 feet as standard width (48 inches)
      const plfValue = psfValue * 4;
      setSubProductDeadLoadPerLinearFoot(plfValue);
    } else {
      setSubProductDeadLoadPerLinearFoot(null);
    }
  }, [subProductDeadLoad]);

  // Form state
  const [productType, setProductType] = useState<ProductType>("Beams");
  const [description, setDescription] = useState("");
  const [tolerances, setTolerances] = useState<ToleranceSpec[]>([]);
  
  // Tolerance form state
  const [showToleranceModal, setShowToleranceModal] = useState(false);
  const [editingToleranceIndex, setEditingToleranceIndex] = useState<number | null>(null);
  const [dimension, setDimension] = useState("");
  const [minValue, setMinValue] = useState("");
  const [maxValue, setMaxValue] = useState("");
  const [notes, setNotes] = useState("");

  const productTypes: ProductType[] = [
    "Beams",
    "Hollow Core Slabs",
    "Solid Slabs",
    "Stadia",
    "Columns",
    "Wall Panels",
    "Stairs",
  ];

  const handleAddTolerance = () => {
    if (!dimension.trim() || !minValue.trim() || !maxValue.trim()) {
      Alert.alert("Error", "Dimension, min value, and max value are required");
      return;
    }

    const newTolerance: ToleranceSpec = {
      dimension: dimension.trim(),
      min: minValue.trim(),
      max: maxValue.trim(),
      notes: notes.trim() || undefined,
    };

    // Check if we're editing sub-product tolerances
    if (showSubProductModal) {
      if (editingToleranceIndex !== null) {
        setSubProductTolerances(subProductTolerances.map((t, i) => (i === editingToleranceIndex ? newTolerance : t)));
      } else {
        setSubProductTolerances([...subProductTolerances, newTolerance]);
      }
    } else {
      // Otherwise, we're editing product tolerances
      if (editingToleranceIndex !== null) {
        setTolerances(tolerances.map((t, i) => (i === editingToleranceIndex ? newTolerance : t)));
      } else {
        setTolerances([...tolerances, newTolerance]);
      }
    }

    // Reset tolerance form
    setDimension("");
    setMinValue("");
    setMaxValue("");
    setNotes("");
    setEditingToleranceIndex(null);
    setShowToleranceModal(false);
  };

  const handleEditTolerance = (index: number) => {
    const tolerance = tolerances[index];
    setDimension(tolerance.dimension);
    setMinValue(tolerance.min);
    setMaxValue(tolerance.max);
    setNotes(tolerance.notes || "");
    setEditingToleranceIndex(index);
    setShowToleranceModal(true);
  };

  const handleDeleteTolerance = (index: number) => {
    setTolerances(tolerances.filter((_, i) => i !== index));
  };

  const handleSaveProduct = () => {
    if (!description.trim()) {
      Alert.alert("Error", "Description is required");
      return;
    }

    if (tolerances.length === 0) {
      Alert.alert("Warning", "Are you sure you want to save without any tolerances?", [
        { text: "Cancel", style: "cancel" },
        { text: "Save Anyway", onPress: () => performSave() },
      ]);
      return;
    }

    performSave();
  };

  const performSave = () => {
    // Check if product type already exists
    const existingProduct = products.find((p) => p.name === productType && p.id !== editingId);
    
    if (existingProduct) {
      Alert.alert("Error", `A product of type "${productType}" already exists. Please edit the existing one.`);
      return;
    }

    if (editingId) {
      updateProduct(editingId, {
        name: productType,
        description,
        tolerances,
      });
    } else {
      addProduct({
        name: productType,
        description,
        tolerances,
        isActive: true,
      });
    }

    resetForm();
    setShowAddModal(false);
  };

  const resetForm = () => {
    setProductType("Beams");
    setDescription("");
    setTolerances([]);
    setEditingId(null);
  };

  const handleEdit = (productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    setEditingId(productId);
    setProductType(product.name);
    setDescription(product.description || "");
    setTolerances([...product.tolerances]);
    setShowAddModal(true);
  };

  const handleDelete = (productId: string) => {
    Alert.alert("Delete Product", "Are you sure you want to delete this product? This action cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => deleteProduct(productId),
      },
    ]);
  };

  // Sub-product handlers
  const handleAddSubProduct = (productId: string) => {
    setCurrentProductId(productId);
    setSubProductName("");
    setSubProductDescription("");
    setSubProductTolerances([]);
    setSubProductArea("");
    setSubProductEffectiveWebWidth("");
    setSubProductMomentOfInertia("");
    setSubProductDistanceToBottomFiber("");
    setSubProductDeadLoad("");
    setSubProductDeadLoadPerLinearFoot(null);
    setSubProductFc28Day("");
    setSubProductFciRelease("");
    setSubProductFpu("");
    setSubProductCrossSectionComponent("");
    setEditingSubProductId(null);
    setShowSubProductModal(true);
  };

  const handleEditSubProduct = (productId: string, subProductId: string) => {
    const product = products.find((p) => p.id === productId);
    const subProduct = product?.subProducts?.find((sp) => sp.id === subProductId);
    if (!subProduct) return;

    setCurrentProductId(productId);
    setEditingSubProductId(subProductId);
    setSubProductName(subProduct.name);
    setSubProductDescription(subProduct.description || "");
    setSubProductTolerances([...subProduct.tolerances]);
    setSubProductArea(subProduct.area?.toString() || "");
    setSubProductEffectiveWebWidth(subProduct.effectiveWebWidth?.toString() || "");
    setSubProductMomentOfInertia(subProduct.momentOfInertia?.toString() || "");
    setSubProductDistanceToBottomFiber(subProduct.distanceToBottomFiber?.toString() || "");
    setSubProductDeadLoad(subProduct.deadLoad || "");
    setSubProductDeadLoadPerLinearFoot(subProduct.deadLoadPerLinearFoot || null);
    setSubProductFc28Day(subProduct.fc28Day?.toString() || "");
    setSubProductFciRelease(subProduct.fciRelease?.toString() || "");
    setSubProductFpu(subProduct.fpu?.toString() || "");
    setSubProductCrossSectionComponent(subProduct.crossSectionComponent || "");
    setShowSubProductModal(true);
  };

  const handleSaveSubProduct = () => {
    if (!currentProductId || !subProductName.trim()) {
      Alert.alert("Error", "Sub-product name is required");
      return;
    }

    const updates: any = {
      name: subProductName,
      description: subProductDescription,
      tolerances: subProductTolerances,
      area: subProductArea ? parseFloat(subProductArea) : undefined,
      effectiveWebWidth: subProductEffectiveWebWidth ? parseFloat(subProductEffectiveWebWidth) : undefined,
      momentOfInertia: subProductMomentOfInertia ? parseFloat(subProductMomentOfInertia) : undefined,
      distanceToBottomFiber: subProductDistanceToBottomFiber ? parseFloat(subProductDistanceToBottomFiber) : undefined,
      deadLoad: subProductDeadLoad || undefined,
      deadLoadPerLinearFoot: subProductDeadLoadPerLinearFoot || undefined,
      fc28Day: subProductFc28Day ? parseInt(subProductFc28Day) : undefined,
      fciRelease: subProductFciRelease ? parseInt(subProductFciRelease) : undefined,
      fpu: subProductFpu ? parseFloat(subProductFpu) : undefined,
      crossSectionComponent: subProductCrossSectionComponent || undefined,
    };

    if (editingSubProductId) {
      updateSubProduct(currentProductId, editingSubProductId, updates);
    } else {
      addSubProduct(currentProductId, {
        ...updates,
        isActive: true,
      });
    }

    setShowSubProductModal(false);
    setCurrentProductId(null);
    setEditingSubProductId(null);
    setSubProductName("");
    setSubProductDescription("");
    setSubProductTolerances([]);
    setSubProductArea("");
    setSubProductEffectiveWebWidth("");
    setSubProductMomentOfInertia("");
    setSubProductDistanceToBottomFiber("");
    setSubProductDeadLoad("");
    setSubProductDeadLoadPerLinearFoot(null);
    setSubProductFc28Day("");
    setSubProductFciRelease("");
    setSubProductFpu("");
    setSubProductCrossSectionComponent("");
  };

  const handleDeleteSubProduct = (productId: string, subProductId: string) => {
    Alert.alert("Delete Sub-Product", "Are you sure you want to delete this sub-product?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => deleteSubProduct(productId, subProductId),
      },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <ScrollView style={{ flex: 1 }}>
        <View style={{ padding: 24 }}>
          {/* Header */}
          <View style={{ marginBottom: 24 }}>
            <Text style={{ fontSize: 28, fontWeight: "700", color: "#111827", marginBottom: 8 }}>
              Product Library
            </Text>
            <Text style={{ fontSize: 16, color: "#6B7280" }}>
              Manage product types and their tolerances
            </Text>
          </View>

          {/* Add Button */}
          <Pressable
            onPress={() => {
              resetForm();
              setShowAddModal(true);
            }}
            style={{
              backgroundColor: "#3B82F6",
              borderRadius: 16,
              padding: 16,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 24,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Ionicons name="add-circle" size={24} color="#FFFFFF" />
            <Text style={{ color: "#FFFFFF", fontSize: 16, fontWeight: "600", marginLeft: 8 }}>
              Add Product Type
            </Text>
          </Pressable>

          {/* Products List */}
          {products.length === 0 ? (
            <View
              style={{
                backgroundColor: "#FFFFFF",
                borderRadius: 16,
                padding: 32,
                alignItems: "center",
                borderWidth: 1,
                borderColor: "#E5E7EB",
              }}
            >
              <Ionicons name="cube-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 18, fontWeight: "600", color: "#111827", marginTop: 12 }}>
                No Products Yet
              </Text>
              <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 8, textAlign: "center" }}>
                Add your first product type to start tracking tolerances.
              </Text>
            </View>
          ) : (
            <View style={{ gap: 12 }}>
              {products
                .sort((a, b) => a.name.localeCompare(b.name))
                .map((product) => {
                  const isExpanded = expandedProductId === product.id;

                  return (
                    <View
                      key={product.id}
                      style={{
                        backgroundColor: "#FFFFFF",
                        borderRadius: 12,
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                        overflow: "hidden",
                      }}
                    >
                      {/* Product Header */}
                      <Pressable
                        onPress={() => setExpandedProductId(isExpanded ? null : product.id)}
                        style={{ padding: 16 }}
                      >
                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                          <View style={{ flex: 1 }}>
                            <Text style={{ fontSize: 18, fontWeight: "600", color: "#111827", marginBottom: 4 }}>
                              {product.name}
                            </Text>
                            <Text style={{ fontSize: 14, color: "#6B7280" }}>
                              {product.description}
                            </Text>
                            <View style={{ flexDirection: "row", alignItems: "center", marginTop: 8, gap: 6 }}>
                              <Ionicons name="resize-outline" size={14} color="#6366F1" />
                              <Text style={{ fontSize: 13, color: "#6366F1", fontWeight: "500" }}>
                                {product.tolerances.length} {product.tolerances.length === 1 ? "tolerance" : "tolerances"}
                              </Text>
                            </View>
                          </View>
                          <View style={{ flexDirection: "row", gap: 8, alignItems: "center" }}>
                            <Pressable
                              onPress={() => handleEdit(product.id)}
                              style={{
                                backgroundColor: "#EFF6FF",
                                padding: 8,
                                borderRadius: 8,
                              }}
                            >
                              <Ionicons name="pencil" size={16} color="#3B82F6" />
                            </Pressable>
                            <Pressable
                              onPress={() => handleDelete(product.id)}
                              style={{
                                backgroundColor: "#FEE2E2",
                                padding: 8,
                                borderRadius: 8,
                              }}
                            >
                              <Ionicons name="trash-outline" size={16} color="#EF4444" />
                            </Pressable>
                            <Ionicons
                              name={isExpanded ? "chevron-up" : "chevron-down"}
                              size={20}
                              color="#6B7280"
                            />
                          </View>
                        </View>
                      </Pressable>

                      {/* Expanded Tolerances and Sub-Products */}
                      {isExpanded && (
                        <View style={{ padding: 16, paddingTop: 0 }}>
                          {/* Sub-Products Section */}
                          {(product.subProducts && product.subProducts.length > 0) && (
                            <View style={{ marginBottom: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: "#E5E7EB" }}>
                              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                                <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151" }}>
                                  Sub-Products ({product.subProducts.length}):
                                </Text>
                                <Pressable
                                  onPress={() => handleAddSubProduct(product.id)}
                                  style={{
                                    backgroundColor: "#10B981",
                                    paddingHorizontal: 10,
                                    paddingVertical: 6,
                                    borderRadius: 6,
                                    flexDirection: "row",
                                    alignItems: "center",
                                    gap: 4,
                                  }}
                                >
                                  <Ionicons name="add" size={16} color="#FFFFFF" />
                                  <Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "600" }}>Add Sub-Product</Text>
                                </Pressable>
                              </View>
                              <View style={{ gap: 8 }}>
                                {product.subProducts.map((subProduct) => {
                                  const isSubExpanded = expandedSubProductId === subProduct.id;
                                  return (
                                    <View
                                      key={subProduct.id}
                                      style={{
                                        backgroundColor: "#F3F4F6",
                                        borderRadius: 8,
                                        borderWidth: 1,
                                        borderColor: "#D1D5DB",
                                        overflow: "hidden",
                                      }}
                                    >
                                      <Pressable
                                        onPress={() => setExpandedSubProductId(isSubExpanded ? null : subProduct.id)}
                                        style={{ padding: 12 }}
                                      >
                                        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                                          <View style={{ flex: 1 }}>
                                            <Text style={{ fontSize: 15, fontWeight: "600", color: "#111827", marginBottom: 2 }}>
                                              {subProduct.name}
                                            </Text>
                                            {subProduct.description && (
                                              <Text style={{ fontSize: 13, color: "#6B7280" }}>
                                                {subProduct.description}
                                              </Text>
                                            )}
                                            <View style={{ flexDirection: "row", alignItems: "center", marginTop: 6, gap: 8, flexWrap: "wrap" }}>
                                              {subProduct.deadLoad && (
                                                <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                                                  <Ionicons name="scale-outline" size={12} color="#8B5CF6" />
                                                  <Text style={{ fontSize: 11, color: "#8B5CF6", fontWeight: "500" }}>
                                                    DL: {subProduct.deadLoad}
                                                  </Text>
                                                </View>
                                              )}
                                              {subProduct.fc28Day && (
                                                <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                                                  <Ionicons name="cube-outline" size={12} color="#F59E0B" />
                                                  <Text style={{ fontSize: 11, color: "#F59E0B", fontWeight: "500" }}>
                                                    f'c: {subProduct.fc28Day} psi
                                                  </Text>
                                                </View>
                                              )}
                                              {subProduct.fciRelease && (
                                                <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                                                  <Ionicons name="flash-outline" size={12} color="#EF4444" />
                                                  <Text style={{ fontSize: 11, color: "#EF4444", fontWeight: "500" }}>
                                                    f'ci: {subProduct.fciRelease} psi
                                                  </Text>
                                                </View>
                                              )}
                                              <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
                                                <Ionicons name="resize-outline" size={12} color="#10B981" />
                                                <Text style={{ fontSize: 11, color: "#10B981", fontWeight: "500" }}>
                                                  {subProduct.tolerances.length} {subProduct.tolerances.length === 1 ? "tolerance" : "tolerances"}
                                                </Text>
                                              </View>
                                            </View>
                                          </View>
                                          <View style={{ flexDirection: "row", gap: 6, alignItems: "center" }}>
                                            <Pressable
                                              onPress={() => handleEditSubProduct(product.id, subProduct.id)}
                                              style={{
                                                backgroundColor: "#DBEAFE",
                                                padding: 6,
                                                borderRadius: 6,
                                              }}
                                            >
                                              <Ionicons name="pencil" size={14} color="#2563EB" />
                                            </Pressable>
                                            <Pressable
                                              onPress={() => handleDeleteSubProduct(product.id, subProduct.id)}
                                              style={{
                                                backgroundColor: "#FEE2E2",
                                                padding: 6,
                                                borderRadius: 6,
                                              }}
                                            >
                                              <Ionicons name="trash-outline" size={14} color="#DC2626" />
                                            </Pressable>
                                            <Ionicons
                                              name={isSubExpanded ? "chevron-up" : "chevron-down"}
                                              size={18}
                                              color="#6B7280"
                                            />
                                          </View>
                                        </View>
                                      </Pressable>

                                      {/* Sub-Product Details */}
                                      {isSubExpanded && (
                                        <View style={{ padding: 12, paddingTop: 0, borderTopWidth: 1, borderTopColor: "#D1D5DB" }}>
                                          {/* Cross-section illustration */}
                                          {subProduct.crossSectionComponent && (
                                            <View style={{ marginBottom: 12, backgroundColor: "#F9FAFB", padding: 12, borderRadius: 6, alignItems: "center" }}>
                                              <Text style={{ fontSize: 12, fontWeight: "600", color: "#4B5563", marginBottom: 8, textAlign: "center" }}>
                                                Cross Section (Cores & Webs)
                                              </Text>
                                              {/* Render the appropriate cross-section component */}
                                              {subProduct.name === '8048' && (
                                                <CrossSection8048 scale={4} showDimensions={false} />
                                              )}
                                              {subProduct.name === '1048' && (
                                                <CrossSection1048 scale={4} showDimensions={false} />
                                              )}
                                              {subProduct.name === '1248' && (
                                                <CrossSection1248 scale={4} showDimensions={false} />
                                              )}
                                              {subProduct.name === '1250' && (
                                                <CrossSection1250 scale={4} showDimensions={false} />
                                              )}
                                              {subProduct.name === '1648' && (
                                                <CrossSection1648 scale={4} showDimensions={false} />
                                              )}
                                              {subProduct.name === '1650' && (
                                                <CrossSection1650 scale={4} showDimensions={false} />
                                              )}
                                            </View>
                                          )}

                                          {/* Cross-Section Properties */}
                                          {(subProduct.area || subProduct.effectiveWebWidth || subProduct.momentOfInertia || subProduct.distanceToBottomFiber) && (
                                            <View style={{ marginBottom: 12 }}>
                                              <Text style={{ fontSize: 13, fontWeight: "600", color: "#4B5563", marginBottom: 8 }}>
                                                Cross-Section Properties:
                                              </Text>
                                              <View style={{ gap: 6 }}>
                                                {subProduct.area && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>A (Area):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#10B981" }}>{subProduct.area} in²</Text>
                                                  </View>
                                                )}
                                                {subProduct.effectiveWebWidth && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>B<Text style={{ fontSize: 9 }}>w</Text> (Effective Web Width):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#10B981" }}>{subProduct.effectiveWebWidth} in</Text>
                                                  </View>
                                                )}
                                                {subProduct.momentOfInertia && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>I<Text style={{ fontSize: 9 }}>g</Text> (Moment of Inertia):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#10B981" }}>{subProduct.momentOfInertia} in⁴</Text>
                                                  </View>
                                                )}
                                                {subProduct.distanceToBottomFiber && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>Y<Text style={{ fontSize: 9 }}>b</Text> (Distance to Bottom):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#10B981" }}>{subProduct.distanceToBottomFiber} in</Text>
                                                  </View>
                                                )}
                                              </View>
                                            </View>
                                          )}

                                          {/* Technical Specifications */}
                                          {(subProduct.deadLoad || subProduct.deadLoadPerLinearFoot || subProduct.fc28Day || subProduct.fciRelease || subProduct.fpu) && (
                                            <View style={{ marginBottom: 12 }}>
                                              <Text style={{ fontSize: 13, fontWeight: "600", color: "#4B5563", marginBottom: 8 }}>
                                                Strength Characteristics:
                                              </Text>
                                              <View style={{ gap: 6 }}>
                                                {subProduct.deadLoad && (
                                                  <View style={{ backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                                                      <Text style={{ fontSize: 12, color: "#6B7280" }}>Dead Load:</Text>
                                                      <Text style={{ fontSize: 12, fontWeight: "600", color: "#8B5CF6" }}>{subProduct.deadLoad} psf</Text>
                                                    </View>
                                                    {subProduct.deadLoadPerLinearFoot && (
                                                      <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
                                                        <Text style={{ fontSize: 11, color: "#9CA3AF" }}>Per Linear Foot:</Text>
                                                        <Text style={{ fontSize: 11, fontWeight: "600", color: "#A78BFA" }}>{subProduct.deadLoadPerLinearFoot.toFixed(1)} plf</Text>
                                                      </View>
                                                    )}
                                                  </View>
                                                )}
                                                {subProduct.fc28Day && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>f'c (28-day):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#F59E0B" }}>{subProduct.fc28Day} psi</Text>
                                                  </View>
                                                )}
                                                {subProduct.fciRelease && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>f'ci (Release):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#EF4444" }}>{subProduct.fciRelease} psi</Text>
                                                  </View>
                                                )}
                                                {subProduct.fpu && (
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFFFFF", padding: 8, borderRadius: 6 }}>
                                                    <Text style={{ fontSize: 12, color: "#6B7280" }}>f'<Text style={{ fontSize: 9 }}>pu</Text> (Strand Strength):</Text>
                                                    <Text style={{ fontSize: 12, fontWeight: "600", color: "#EC4899" }}>{subProduct.fpu} ksi</Text>
                                                  </View>
                                                )}
                                              </View>
                                            </View>
                                          )}

                                          {/* Tolerances */}
                                          <Text style={{ fontSize: 13, fontWeight: "600", color: "#4B5563", marginBottom: 8 }}>
                                            Tolerances:
                                          </Text>
                                          {subProduct.tolerances.length === 0 ? (
                                            <Text style={{ fontSize: 12, color: "#9CA3AF", fontStyle: "italic" }}>
                                              No tolerances defined
                                            </Text>
                                          ) : (
                                            <View style={{ gap: 6 }}>
                                              {subProduct.tolerances.map((tolerance, index) => (
                                                <View
                                                  key={index}
                                                  style={{
                                                    backgroundColor: "#FFFFFF",
                                                    padding: 10,
                                                    borderRadius: 6,
                                                    borderWidth: 1,
                                                    borderColor: "#E5E7EB",
                                                  }}
                                                >
                                                  <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                                                    <Text style={{ fontSize: 13, fontWeight: "600", color: "#111827" }}>
                                                      {tolerance.dimension}
                                                    </Text>
                                                    <Text style={{ fontSize: 13, fontWeight: "600", color: "#10B981" }}>
                                                      {tolerance.min} to {tolerance.max}
                                                    </Text>
                                                  </View>
                                                  {tolerance.notes && (
                                                    <Text style={{ fontSize: 11, color: "#6B7280", marginTop: 4 }}>
                                                      {tolerance.notes}
                                                    </Text>
                                                  )}
                                                </View>
                                              ))}
                                            </View>
                                          )}
                                        </View>
                                      )}
                                    </View>
                                  );
                                })}
                              </View>
                            </View>
                          )}

                          {/* Add Sub-Product Button (if no sub-products yet) */}
                          {(!product.subProducts || product.subProducts.length === 0) && (
                            <View style={{ marginBottom: 16, paddingTop: 16, borderTopWidth: 1, borderTopColor: "#E5E7EB" }}>
                              <Pressable
                                onPress={() => handleAddSubProduct(product.id)}
                                style={{
                                  backgroundColor: "#F0FDF4",
                                  padding: 12,
                                  borderRadius: 8,
                                  borderWidth: 1,
                                  borderColor: "#86EFAC",
                                  flexDirection: "row",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  gap: 6,
                                }}
                              >
                                <Ionicons name="add-circle" size={18} color="#10B981" />
                                <Text style={{ color: "#10B981", fontSize: 13, fontWeight: "600" }}>
                                  Add Sub-Product Type
                                </Text>
                              </Pressable>
                            </View>
                          )}

                          {/* Product-level Tolerances */}
                          <View style={{ borderTopWidth: 1, borderTopColor: "#E5E7EB", paddingTop: 16 }}>
                            <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 12 }}>
                              Product Tolerances:
                            </Text>
                            {product.tolerances.length === 0 ? (
                              <Text style={{ fontSize: 13, color: "#9CA3AF", fontStyle: "italic" }}>
                                No tolerances defined
                              </Text>
                            ) : (
                              <View style={{ gap: 8 }}>
                                {product.tolerances.map((tolerance, index) => (
                                  <View
                                    key={index}
                                    style={{
                                      backgroundColor: "#F9FAFB",
                                      padding: 12,
                                      borderRadius: 8,
                                      borderWidth: 1,
                                      borderColor: "#E5E7EB",
                                    }}
                                  >
                                    <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 4 }}>
                                      <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827" }}>
                                        {tolerance.dimension}
                                      </Text>
                                      <Text style={{ fontSize: 14, fontWeight: "600", color: "#6366F1" }}>
                                        {tolerance.min} to {tolerance.max}
                                      </Text>
                                    </View>
                                    {tolerance.notes && (
                                      <Text style={{ fontSize: 12, color: "#6B7280", marginTop: 4 }}>
                                        {tolerance.notes}
                                      </Text>
                                    )}
                                  </View>
                                ))}
                              </View>
                            )}
                          </View>
                        </View>
                      )}
                    </View>
                  );
                })}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Add/Edit Product Modal */}
      <Modal visible={showAddModal && !showToleranceModal} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
          style={{ flex: 1 }}
          keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
        >
          <Pressable
            style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
            onPress={Keyboard.dismiss}
          >
            <Pressable onPress={(e) => e.stopPropagation()}>
              <View
                style={{
                  backgroundColor: "#FFFFFF",
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  padding: 24,
                  paddingBottom: insets.bottom + 24,
                  maxHeight: "90%",
                }}
              >
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
                <Text style={{ fontSize: 20, fontWeight: "600", color: "#111827" }}>
                  {editingId ? "Edit Product" : "Add Product Type"}
                </Text>
                <Pressable onPress={() => setShowAddModal(false)}>
                  <Ionicons name="close" size={24} color="#6B7280" />
                </Pressable>
              </View>

              <ScrollView style={{ maxHeight: 500 }} keyboardShouldPersistTaps="handled">
                <View style={{ gap: 16 }}>
                  {/* Product Type */}
                  <View>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Product Type *
                    </Text>
                    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                      {productTypes.map((type) => (
                        <Pressable
                          key={type}
                          onPress={() => setProductType(type)}
                          style={{
                            backgroundColor: productType === type ? "#3B82F6" : "#F3F4F6",
                            paddingVertical: 8,
                            paddingHorizontal: 12,
                            borderRadius: 8,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 13,
                              fontWeight: "600",
                              color: productType === type ? "#FFFFFF" : "#6B7280",
                            }}
                          >
                            {type}
                          </Text>
                        </Pressable>
                      ))}
                    </View>
                  </View>

                  {/* Description */}
                  <View>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Description *
                    </Text>
                    <TextInput
                      value={description}
                      onChangeText={setDescription}
                      placeholder="Brief description of this product type..."
                      placeholderTextColor="#9CA3AF"
                      cursorColor="#000000"
                      selectionColor="#3B82F6"
                      multiline
                      numberOfLines={2}
                      textAlignVertical="top"
                      style={{
                        backgroundColor: "#F9FAFB",
                        borderRadius: 12,
                        padding: 12,
                        fontSize: 14,
                        color: "#111827",
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                        minHeight: 60,
                      }}
                    />
                  </View>

                  {/* Tolerances */}
                  <View>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                      <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151" }}>
                        Tolerances
                      </Text>
                      <Pressable
                        onPress={() => {
                          setDimension("");
                          setMinValue("");
                          setMaxValue("");
                          setNotes("");
                          setEditingToleranceIndex(null);
                          setShowToleranceModal(true);
                        }}
                        style={{
                          backgroundColor: "#10B981",
                          paddingHorizontal: 10,
                          paddingVertical: 6,
                          borderRadius: 6,
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 4,
                        }}
                      >
                        <Ionicons name="add" size={16} color="#FFFFFF" />
                        <Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "600" }}>Add</Text>
                      </Pressable>
                    </View>

                    {tolerances.length === 0 ? (
                      <View
                        style={{
                          backgroundColor: "#F9FAFB",
                          padding: 16,
                          borderRadius: 8,
                          alignItems: "center",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      >
                        <Text style={{ fontSize: 13, color: "#9CA3AF" }}>
                          No tolerances added yet
                        </Text>
                      </View>
                    ) : (
                      <View style={{ gap: 8 }}>
                        {tolerances.map((tolerance, index) => (
                          <View
                            key={index}
                            style={{
                              backgroundColor: "#F9FAFB",
                              padding: 12,
                              borderRadius: 8,
                              borderWidth: 1,
                              borderColor: "#E5E7EB",
                            }}
                          >
                            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                              <View style={{ flex: 1 }}>
                                <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 2 }}>
                                  {tolerance.dimension}: {tolerance.min} to {tolerance.max}
                                </Text>
                                {tolerance.notes && (
                                  <Text style={{ fontSize: 12, color: "#6B7280" }}>
                                    {tolerance.notes}
                                  </Text>
                                )}
                              </View>
                              <View style={{ flexDirection: "row", gap: 8 }}>
                                <Pressable
                                  onPress={() => handleEditTolerance(index)}
                                  style={{ padding: 4 }}
                                >
                                  <Ionicons name="pencil" size={16} color="#3B82F6" />
                                </Pressable>
                                <Pressable
                                  onPress={() => handleDeleteTolerance(index)}
                                  style={{ padding: 4 }}
                                >
                                  <Ionicons name="trash-outline" size={16} color="#EF4444" />
                                </Pressable>
                              </View>
                            </View>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>
                </View>
              </ScrollView>

              <View style={{ flexDirection: "row", gap: 12, marginTop: 24 }}>
                <Pressable
                  onPress={() => setShowAddModal(false)}
                  style={{
                    flex: 1,
                    backgroundColor: "#F3F4F6",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#6B7280", fontSize: 16, fontWeight: "600" }}>Cancel</Text>
                </Pressable>
                <Pressable
                  onPress={handleSaveProduct}
                  style={{
                    flex: 1,
                    backgroundColor: "#3B82F6",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#FFFFFF", fontSize: 16, fontWeight: "600" }}>
                    {editingId ? "Update" : "Save"}
                  </Text>
                </Pressable>
              </View>
            </View>
            </Pressable>
          </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      {/* Add/Edit Tolerance Modal */}
      <Modal visible={showToleranceModal} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
          style={{ flex: 1 }}
          keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
        >
          <Pressable
            style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
            onPress={Keyboard.dismiss}
          >
            <Pressable onPress={(e) => e.stopPropagation()}>
              <View
                style={{
                backgroundColor: "#FFFFFF",
                borderTopLeftRadius: 24,
                borderTopRightRadius: 24,
                padding: 24,
                paddingBottom: insets.bottom + 24,
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
                <Text style={{ fontSize: 20, fontWeight: "600", color: "#111827" }}>
                  {editingToleranceIndex !== null ? "Edit Tolerance" : "Add Tolerance"}
                </Text>
                <Pressable onPress={() => setShowToleranceModal(false)}>
                  <Ionicons name="close" size={24} color="#6B7280" />
                </Pressable>
              </View>

              <View style={{ gap: 16 }}>
                <View>
                  <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                    Dimension *
                  </Text>
                  <TextInput
                    value={dimension}
                    onChangeText={setDimension}
                    placeholder="e.g., Length, Width, Thickness"
                    placeholderTextColor="#9CA3AF"
                    cursorColor="#000000"
                    selectionColor="#3B82F6"
                    style={{
                      backgroundColor: "#F9FAFB",
                      borderRadius: 12,
                      padding: 12,
                      fontSize: 14,
                      color: "#111827",
                      borderWidth: 1,
                      borderColor: "#E5E7EB",
                    }}
                  />
                </View>

                <View style={{ flexDirection: "row", gap: 12 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Min Value *
                    </Text>
                    <TextInput
                      value={minValue}
                      onChangeText={setMinValue}
                      placeholder="e.g., -1/8, 0"
                      placeholderTextColor="#9CA3AF"
                      cursorColor="#000000"
                      selectionColor="#3B82F6"
                      style={{
                        backgroundColor: "#F9FAFB",
                        borderRadius: 12,
                        padding: 12,
                        fontSize: 14,
                        color: "#111827",
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                      }}
                    />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Max Value *
                    </Text>
                    <TextInput
                      value={maxValue}
                      onChangeText={setMaxValue}
                      placeholder="e.g., +1/8, +1/4"
                      placeholderTextColor="#9CA3AF"
                      cursorColor="#000000"
                      selectionColor="#3B82F6"
                      style={{
                        backgroundColor: "#F9FAFB",
                        borderRadius: 12,
                        padding: 12,
                        fontSize: 14,
                        color: "#111827",
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                      }}
                    />
                  </View>
                </View>

                <View>
                  <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                    Notes (Optional)
                  </Text>
                  <TextInput
                    value={notes}
                    onChangeText={setNotes}
                    placeholder="Additional details..."
                    placeholderTextColor="#9CA3AF"
                    cursorColor="#000000"
                    selectionColor="#3B82F6"
                    multiline
                    numberOfLines={2}
                    textAlignVertical="top"
                    style={{
                      backgroundColor: "#F9FAFB",
                      borderRadius: 12,
                      padding: 12,
                      fontSize: 14,
                      color: "#111827",
                      borderWidth: 1,
                      borderColor: "#E5E7EB",
                      minHeight: 60,
                    }}
                  />
                </View>
              </View>

              <View style={{ flexDirection: "row", gap: 12, marginTop: 24 }}>
                <Pressable
                  onPress={() => setShowToleranceModal(false)}
                  style={{
                    flex: 1,
                    backgroundColor: "#F3F4F6",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#6B7280", fontSize: 16, fontWeight: "600" }}>Cancel</Text>
                </Pressable>
                <Pressable
                  onPress={handleAddTolerance}
                  style={{
                    flex: 1,
                    backgroundColor: "#10B981",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#FFFFFF", fontSize: 16, fontWeight: "600" }}>
                    {editingToleranceIndex !== null ? "Update" : "Add"}
                  </Text>
                </Pressable>
              </View>
              </View>
            </Pressable>
          </Pressable>
        </KeyboardAvoidingView>
      </Modal>

      {/* Add/Edit Sub-Product Modal */}
      <Modal visible={showSubProductModal && !showToleranceModal} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
          style={{ flex: 1 }}
          keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
        >
          <Pressable
            style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
            onPress={Keyboard.dismiss}
          >
            <Pressable onPress={(e) => e.stopPropagation()}>
              <View
                style={{
                backgroundColor: "#FFFFFF",
                borderTopLeftRadius: 24,
                borderTopRightRadius: 24,
                padding: 24,
                paddingBottom: insets.bottom + 24,
                maxHeight: "90%",
              }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
                <Text style={{ fontSize: 20, fontWeight: "600", color: "#111827" }}>
                  {editingSubProductId ? "Edit Sub-Product" : "Add Sub-Product"}
                </Text>
                <Pressable onPress={() => setShowSubProductModal(false)}>
                  <Ionicons name="close" size={24} color="#6B7280" />
                </Pressable>
              </View>

              <ScrollView style={{ maxHeight: 500 }} keyboardShouldPersistTaps="handled">
                <View style={{ gap: 16 }}>
                  {/* Sub-Product Name */}
                  <View>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Sub-Product Name *
                    </Text>
                    <TextInput
                      value={subProductName}
                      onChangeText={setSubProductName}
                      placeholder="e.g., 8048, 1048, 1248, 1250"
                      placeholderTextColor="#9CA3AF"
                      cursorColor="#000000"
                      selectionColor="#3B82F6"
                      style={{
                        backgroundColor: "#F9FAFB",
                        borderRadius: 12,
                        padding: 12,
                        fontSize: 14,
                        color: "#111827",
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                      }}
                    />
                  </View>

                  {/* Description */}
                  <View>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151", marginBottom: 8 }}>
                      Description
                    </Text>
                    <TextInput
                      value={subProductDescription}
                      onChangeText={setSubProductDescription}
                      placeholder="Brief description..."
                      placeholderTextColor="#9CA3AF"
                      cursorColor="#000000"
                      selectionColor="#3B82F6"
                      multiline
                      numberOfLines={2}
                      textAlignVertical="top"
                      style={{
                        backgroundColor: "#F9FAFB",
                        borderRadius: 12,
                        padding: 12,
                        fontSize: 14,
                        color: "#111827",
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                        minHeight: 60,
                      }}
                    />
                  </View>

                  {/* Cross-Section Properties */}
                  <View style={{ backgroundColor: "#F0FDF4", padding: 12, borderRadius: 12, borderWidth: 1, borderColor: "#86EFAC" }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#065F46", marginBottom: 12 }}>
                      Cross-Section Properties
                    </Text>

                    {/* Area (A) */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        A - Area (in²)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Area of concrete in the cross-section
                      </Text>
                      <TextInput
                        value={subProductArea}
                        onChangeText={setSubProductArea}
                        placeholder="e.g., 293, 373"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>

                    {/* Effective Web Width (Bw) */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        B<Text style={{ fontSize: 10 }}>w</Text> - Effective Web Width (in)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Effective web width
                      </Text>
                      <TextInput
                        value={subProductEffectiveWebWidth}
                        onChangeText={setSubProductEffectiveWebWidth}
                        placeholder="e.g., 24.5, 28.2"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>

                    {/* Moment of Inertia (Ig) */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        I<Text style={{ fontSize: 10 }}>g</Text> - Moment of Inertia (in⁴)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Moment of inertia of the cross-section
                      </Text>
                      <TextInput
                        value={subProductMomentOfInertia}
                        onChangeText={setSubProductMomentOfInertia}
                        placeholder="e.g., 5107, 10780"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>

                    {/* Distance to Bottom Fiber (Yb) */}
                    <View>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        Y<Text style={{ fontSize: 10 }}>b</Text> - Distance to Bottom Fiber (in)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Distance from neutral axis to extreme bottom fiber
                      </Text>
                      <TextInput
                        value={subProductDistanceToBottomFiber}
                        onChangeText={setSubProductDistanceToBottomFiber}
                        placeholder="e.g., 4.0, 6.0"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>
                  </View>

                  {/* Technical Specifications */}
                  <View style={{ backgroundColor: "#F0F9FF", padding: 12, borderRadius: 12, borderWidth: 1, borderColor: "#BFDBFE" }}>
                    <Text style={{ fontSize: 14, fontWeight: "600", color: "#1E40AF", marginBottom: 12 }}>
                      Strength Characteristics
                    </Text>

                    {/* Dead Load */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        Dead Load (psf)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Pounds per square foot
                      </Text>
                      <TextInput
                        value={subProductDeadLoad}
                        onChangeText={setSubProductDeadLoad}
                        placeholder="e.g., 65, 80, 95"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                      {subProductDeadLoadPerLinearFoot !== null && (
                        <View style={{ marginTop: 8, backgroundColor: "#F0F9FF", padding: 8, borderRadius: 6, borderWidth: 1, borderColor: "#BFDBFE" }}>
                          <Text style={{ fontSize: 12, color: "#1E40AF", fontWeight: "600" }}>
                            Per Linear Foot: {subProductDeadLoadPerLinearFoot.toFixed(1)} plf
                          </Text>
                          <Text style={{ fontSize: 10, color: "#6B7280", marginTop: 2 }}>
                            Based on 4 ft (48 in) width
                          </Text>
                        </View>
                      )}
                    </View>

                    {/* f'c - 28 Day Strength */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 6 }}>
                        f'c - 28-Day Strength (psi)
                      </Text>
                      <TextInput
                        value={subProductFc28Day}
                        onChangeText={setSubProductFc28Day}
                        placeholder="e.g., 5000, 6000"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="numeric"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>

                    {/* f'ci - Release Strength */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 6 }}>
                        f'ci - Release Strength (psi)
                      </Text>
                      <TextInput
                        value={subProductFciRelease}
                        onChangeText={setSubProductFciRelease}
                        placeholder="e.g., 3500, 4000"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="numeric"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>

                    {/* f'pu - Ultimate Tensile Strength of Strand */}
                    <View style={{ marginBottom: 12 }}>
                      <Text style={{ fontSize: 13, fontWeight: "600", color: "#374151", marginBottom: 4 }}>
                        f'<Text style={{ fontSize: 10 }}>pu</Text> - Ultimate Tensile Strength (ksi)
                      </Text>
                      <Text style={{ fontSize: 11, color: "#6B7280", marginBottom: 6 }}>
                        Ultimate tensile strength of the strand
                      </Text>
                      <TextInput
                        value={subProductFpu}
                        onChangeText={setSubProductFpu}
                        placeholder="e.g., 270"
                        placeholderTextColor="#9CA3AF"
                        cursorColor="#000000"
                        selectionColor="#3B82F6"
                        keyboardType="decimal-pad"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderRadius: 8,
                          padding: 10,
                          fontSize: 14,
                          color: "#111827",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      />
                    </View>
                  </View>

                  {/* Tolerances */}
                  <View>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                      <Text style={{ fontSize: 14, fontWeight: "600", color: "#374151" }}>
                        Tolerances
                      </Text>
                      <Pressable
                        onPress={() => {
                          setDimension("");
                          setMinValue("");
                          setMaxValue("");
                          setNotes("");
                          setEditingToleranceIndex(null);
                          setShowToleranceModal(true);
                        }}
                        style={{
                          backgroundColor: "#10B981",
                          paddingHorizontal: 10,
                          paddingVertical: 6,
                          borderRadius: 6,
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 4,
                        }}
                      >
                        <Ionicons name="add" size={16} color="#FFFFFF" />
                        <Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "600" }}>Add</Text>
                      </Pressable>
                    </View>

                    {subProductTolerances.length === 0 ? (
                      <View
                        style={{
                          backgroundColor: "#F9FAFB",
                          padding: 16,
                          borderRadius: 8,
                          alignItems: "center",
                          borderWidth: 1,
                          borderColor: "#E5E7EB",
                        }}
                      >
                        <Text style={{ fontSize: 13, color: "#9CA3AF" }}>
                          No tolerances added yet
                        </Text>
                      </View>
                    ) : (
                      <View style={{ gap: 8 }}>
                        {subProductTolerances.map((tolerance, index) => (
                          <View
                            key={index}
                            style={{
                              backgroundColor: "#F9FAFB",
                              padding: 12,
                              borderRadius: 8,
                              borderWidth: 1,
                              borderColor: "#E5E7EB",
                            }}
                          >
                            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                              <View style={{ flex: 1 }}>
                                <Text style={{ fontSize: 14, fontWeight: "600", color: "#111827", marginBottom: 2 }}>
                                  {tolerance.dimension}: {tolerance.min} to {tolerance.max}
                                </Text>
                                {tolerance.notes && (
                                  <Text style={{ fontSize: 12, color: "#6B7280" }}>
                                    {tolerance.notes}
                                  </Text>
                                )}
                              </View>
                              <View style={{ flexDirection: "row", gap: 8 }}>
                                <Pressable
                                  onPress={() => {
                                    setDimension(tolerance.dimension);
                                    setMinValue(tolerance.min);
                                    setMaxValue(tolerance.max);
                                    setNotes(tolerance.notes || "");
                                    setEditingToleranceIndex(index);
                                    setShowToleranceModal(true);
                                  }}
                                  style={{ padding: 4 }}
                                >
                                  <Ionicons name="pencil" size={16} color="#3B82F6" />
                                </Pressable>
                                <Pressable
                                  onPress={() => setSubProductTolerances(subProductTolerances.filter((_, i) => i !== index))}
                                  style={{ padding: 4 }}
                                >
                                  <Ionicons name="trash-outline" size={16} color="#EF4444" />
                                </Pressable>
                              </View>
                            </View>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>
                </View>
              </ScrollView>

              <View style={{ flexDirection: "row", gap: 12, marginTop: 24 }}>
                <Pressable
                  onPress={() => setShowSubProductModal(false)}
                  style={{
                    flex: 1,
                    backgroundColor: "#F3F4F6",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#6B7280", fontSize: 16, fontWeight: "600" }}>Cancel</Text>
                </Pressable>
                <Pressable
                  onPress={handleSaveSubProduct}
                  style={{
                    flex: 1,
                    backgroundColor: "#10B981",
                    paddingVertical: 12,
                    borderRadius: 12,
                    alignItems: "center",
                  }}
                >
                  <Text style={{ color: "#FFFFFF", fontSize: 16, fontWeight: "600" }}>
                    {editingSubProductId ? "Update" : "Save"}
                  </Text>
                </Pressable>
              </View>
            </View>
          </Pressable>
        </Pressable>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}
